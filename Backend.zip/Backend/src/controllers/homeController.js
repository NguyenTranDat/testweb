let getHomePage = (req, res) => {
    return res.send("abc123");
}

module.exports = {
    getHomePage
}