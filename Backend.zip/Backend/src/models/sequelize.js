const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('fall2324w3g5', 'fall2324w3g5', 'qwertyuiop', {
  host: 'localhost',
  dialect: 'mysql',
});

sequelize.authenticate().then(() => {
  console.log('Kết nối cơ sở dữ liệu thành công.');
}).catch((error) => {
  console.error('Lỗi kết nối cơ sở dữ liệu:', error);
});

module.exports = sequelize;
