//dùng để gọi các thông tin user để tạo mấy trang như treding, ...
import { Express } from "express";
import userController from "../controllers/userController"

const router = Express.router();

//router.get("/getUser")
